package com.example.carmod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

public class CarEntity extends Entity {
    public static final int PART_FRESHENER = 1;
    public static final int PART_MAT = 2;
    public static final int PART_SPOILER = 4;

    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(CarEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> PARTS = SynchedEntityData.defineId(CarEntity.class, EntityDataSerializers.INT);

    private static final EntityDataAccessor<Integer> FLASH = SynchedEntityData.defineId(CarEntity.class, EntityDataSerializers.INT);

    private float speed;

    public CarEntity(EntityType<?> type, Level level) {
        super(type, level);
        setMaxUpStep(1.0F);
    }

    public int getVariant() { return entityData.get(VARIANT); }
    public void setVariant(int v) { entityData.set(VARIANT, v); }
    /** Selektor: 16 tick'lik cift yanip sonme. */
    public void flash() {
        if (entityData.get(FLASH) <= 0) entityData.set(FLASH, 16);
    }

    /** Farlar su an parlak mi? (cift flas deseni) */
    public boolean isFlashLit() {
        int t = entityData.get(FLASH);
        return t > 0 && (t / 4) % 2 == 1;
    }

    public boolean hasPart(int bit) { return (entityData.get(PARTS) & bit) != 0; }

    @Override
    protected void defineSynchedData() {
        entityData.define(VARIANT, 0);
        entityData.define(PARTS, 0);
        entityData.define(FLASH, 0);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag t) {
        entityData.set(VARIANT, t.getInt("Variant"));
        entityData.set(PARTS, t.getInt("Parts"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag t) {
        t.putInt("Variant", getVariant());
        t.putInt("Parts", entityData.get(PARTS));
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override public boolean isPickable() { return true; }
    @Override public boolean canBeCollidedWith() { return true; }
    @Override protected boolean canAddPassenger(Entity e) { return getPassengers().size() < 2; }
    @Override public double getPassengersRidingOffset() { return 0.6; }

    @Override
    public LivingEntity getControllingPassenger() {
        return getFirstPassenger() instanceof LivingEntity l ? l : null;
    }

    @Override
    protected void positionRider(Entity pass, MoveFunction f) {
        if (!hasPassenger(pass)) return;
        double side = getPassengers().indexOf(pass) == 0 ? 0.4 : -0.4; // surucu solda
        Vec3 off = new Vec3(side, 0, 0.1).yRot(-getYRot() * ((float) Math.PI / 180F));
        f.accept(pass, getX() + off.x, getY() + getPassengersRidingOffset() + pass.getMyRidingOffset(), getZ() + off.z);
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (stack.getItem() instanceof CarPartItem part) {
            if (!level().isClientSide && !hasPart(part.bit)) {
                entityData.set(PARTS, entityData.get(PARTS) | part.bit);
                if (!player.getAbilities().instabuild) stack.shrink(1);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (!level().isClientSide) return player.startRiding(this) ? InteractionResult.CONSUME : InteractionResult.PASS;
        return InteractionResult.SUCCESS;
    }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (level().isClientSide || isRemoved()) return true;
        if (src.getEntity() instanceof Player) {
            spawnAtLocation(new ItemStack(getVariant() == 0 ? CarMod.SPORTS_CAR.get() : CarMod.CITY_VAN.get()));
            discard();
        }
        return true;
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && entityData.get(FLASH) > 0) {
            entityData.set(FLASH, entityData.get(FLASH) - 1);
        }
        if (!isControlledByLocalInstance()) return;

        Player p = getControllingPassenger() instanceof Player pl ? pl : null;
        float max = getVariant() == 0 ? 1.6F : 0.9F; // blok/tick (1.0 = 20 blok/sn)

        if (p != null) {
            if (p.zza > 0) speed = Math.min(speed + 0.03F, max);
            else if (p.zza < 0) speed = Math.max(speed - 0.05F, -max / 3F);
            else speed *= 0.97F;
            if (Math.abs(speed) < 0.005F) speed = 0;
            setYRot(getYRot() - p.xxa * 4F * Math.signum(speed) * Math.min(1F, Math.abs(speed) * 2F));
        } else {
            speed *= 0.9F;
        }

        Vec3 dir = Vec3.directionFromRotation(0, getYRot());
        double vy = onGround() ? -0.1 : getDeltaMovement().y - 0.08;
        setDeltaMovement(dir.x * speed, vy, dir.z * speed);
        move(MoverType.SELF, getDeltaMovement());
        if (horizontalCollision) speed *= 0.5F;
    }
}
