package com.example.carmod;

import net.minecraft.world.item.Item;

public class CarPartItem extends Item {
    public final int bit;

    public CarPartItem(int bit, Properties props) {
        super(props);
        this.bit = bit;
    }
}
