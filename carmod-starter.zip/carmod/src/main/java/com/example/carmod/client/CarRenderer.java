package com.example.carmod.client;

import com.example.carmod.CarEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Gecici renderer: vanilla bloklardan kutu arac cizer.
 * Sonra GeckoLib / Blockbench modeli ile degistirilecek.
 * Yerel eksen: on = -Z, arka = +Z.
 */
public class CarRenderer extends EntityRenderer<CarEntity> {
    public CarRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public ResourceLocation getTextureLocation(CarEntity e) {
        return new ResourceLocation("minecraft", "textures/block/white_concrete.png");
    }

    private void box(PoseStack ps, MultiBufferSource b, int light, BlockState s,
                     double x, double y, double z, double sx, double sy, double sz) {
        ps.pushPose();
        ps.translate(x - sx / 2, y, z - sz / 2);
        ps.scale((float) sx, (float) sy, (float) sz);
        Minecraft.getInstance().getBlockRenderer().renderSingleBlock(s, ps, b, light, OverlayTexture.NO_OVERLAY);
        ps.popPose();
    }

    @Override
    public void render(CarEntity car, float yaw, float pt, PoseStack ps, MultiBufferSource buf, int light) {
        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(180F - yaw));

        BlockState black = Blocks.BLACK_CONCRETE.defaultBlockState();
        boolean sports = car.getVariant() == 0;
        BlockState paint = (sports ? Blocks.RED_CONCRETE : Blocks.WHITE_CONCRETE).defaultBlockState();

        if (sports) {
            box(ps, buf, light, paint, 0, 0.30, 0, 1.8, 0.45, 4.2);      // govde
            box(ps, buf, light, black, 0, 0.75, 0.3, 1.5, 0.35, 1.8);    // kabin
        } else {
            box(ps, buf, light, paint, 0, 0.35, 0, 1.8, 0.95, 4.0);      // govde
            box(ps, buf, light, black, 0, 0.95, -0.4, 1.82, 0.35, 2.4);  // cam bandi
        }
        // tekerlekler
        for (int sx = -1; sx <= 1; sx += 2)
            for (int sz = -1; sz <= 1; sz += 2)
                box(ps, buf, light, black, sx * 0.95, 0, sz * 1.3, 0.25, 0.55, 0.55);

        // --- Farlar (selektorde tam parlak) ---
        boolean lit = car.isFlashLit();
        BlockState lamp = (lit ? Blocks.SEA_LANTERN : Blocks.LIGHT_GRAY_CONCRETE).defaultBlockState();
        int lampLight = lit ? LightTexture.FULL_BRIGHT : light;
        double fz = sports ? -2.11 : -2.01;
        double fy = sports ? 0.48 : 0.75;
        for (int sx = -1; sx <= 1; sx += 2)
            box(ps, buf, lampLight, lamp, sx * 0.62, fy, fz, 0.4, 0.12, 0.05);

        // --- Modifiye parcalari ---
        if (car.hasPart(CarEntity.PART_MAT)) {
            box(ps, buf, light, Blocks.GRAY_CONCRETE.defaultBlockState(), 0.4, 0.52, 0.1, 0.7, 0.03, 0.8);
            box(ps, buf, light, Blocks.GRAY_CONCRETE.defaultBlockState(), -0.4, 0.52, 0.1, 0.7, 0.03, 0.8);
        }
        if (car.hasPart(CarEntity.PART_FRESHENER)) { // dikiz aynasinda yesil agac
            box(ps, buf, light, Blocks.LIME_CONCRETE.defaultBlockState(), 0, sports ? 0.95 : 1.2, -0.45, 0.12, 0.28, 0.03);
        }
        if (car.hasPart(CarEntity.PART_SPOILER)) {
            box(ps, buf, light, black, 0, sports ? 1.0 : 1.35, 1.9, 1.7, 0.05, 0.4);
            box(ps, buf, light, black, 0.6, sports ? 0.75 : 1.1, 1.9, 0.05, 0.3, 0.05);
            box(ps, buf, light, black, -0.6, sports ? 0.75 : 1.1, 1.9, 0.05, 0.3, 0.05);
        }

        ps.popPose();
        super.render(car, yaw, pt, ps, buf, light);
    }
}
