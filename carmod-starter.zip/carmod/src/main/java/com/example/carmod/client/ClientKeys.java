package com.example.carmod.client;

import com.example.carmod.CarEntity;
import com.example.carmod.CarMod;
import com.example.carmod.FlashPacket;
import com.example.carmod.Net;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

public class ClientKeys {
    public static final KeyMapping FLASH = new KeyMapping("key.carmod.flash",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.carmod");

    @Mod.EventBusSubscriber(modid = CarMod.ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ModBus {
        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent e) {
            e.register(FLASH);
        }
    }

    @Mod.EventBusSubscriber(modid = CarMod.ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
    public static class ForgeBus {
        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            LocalPlayer p = Minecraft.getInstance().player;
            while (FLASH.consumeClick()) {
                if (p != null && p.getVehicle() instanceof CarEntity car && car.getControllingPassenger() == p) {
                    Net.CH.sendToServer(new FlashPacket());
                }
            }
        }
    }
}
