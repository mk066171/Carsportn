package com.example.carmod;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class CarItem extends Item {
    private final int variant;

    public CarItem(int variant, Properties props) {
        super(props);
        this.variant = variant;
    }

    @Override
    public InteractionResult useOn(UseOnContext c) {
        Level level = c.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        Player p = c.getPlayer();
        CarEntity car = new CarEntity(CarMod.CAR.get(), level);
        car.setVariant(variant);
        BlockPos pos = c.getClickedPos().relative(c.getClickedFace());
        car.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, p != null ? p.getYRot() : 0, 0);
        level.addFreshEntity(car);
        if (p == null || !p.getAbilities().instabuild) c.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }
}
