package com.example.carmod;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

public class FlashPacket {
    public static void encode(FlashPacket p, FriendlyByteBuf b) {}
    public static FlashPacket decode(FriendlyByteBuf b) { return new FlashPacket(); }

    public static void handle(FlashPacket p, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer pl = c.getSender();
            if (pl != null && pl.getVehicle() instanceof CarEntity car && car.getControllingPassenger() == pl) {
                car.flash();
            }
        });
        c.setPacketHandled(true);
    }
}
