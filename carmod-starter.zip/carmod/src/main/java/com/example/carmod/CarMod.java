package com.example.carmod;

import com.example.carmod.client.CarRenderer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(CarMod.ID)
public class CarMod {
    public static final String ID = "carmod";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);

    public static final RegistryObject<EntityType<CarEntity>> CAR = ENTITIES.register("car",
            () -> EntityType.Builder.<CarEntity>of(CarEntity::new, MobCategory.MISC)
                    .sized(1.9f, 1.3f).clientTrackingRange(16).updateInterval(1).build("car"));

    // Arac itemleri (variant 0 = spor araba, 1 = van)
    public static final RegistryObject<Item> SPORTS_CAR = ITEMS.register("sports_car", () -> new CarItem(0, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> CITY_VAN = ITEMS.register("city_van", () -> new CarItem(1, new Item.Properties().stacksTo(1)));

    // Modifiye parcalari
    public static final RegistryObject<Item> AIR_FRESHENER = ITEMS.register("air_freshener", () -> new CarPartItem(CarEntity.PART_FRESHENER, new Item.Properties()));
    public static final RegistryObject<Item> FLOOR_MAT = ITEMS.register("floor_mat", () -> new CarPartItem(CarEntity.PART_MAT, new Item.Properties()));
    public static final RegistryObject<Item> SPOILER = ITEMS.register("spoiler", () -> new CarPartItem(CarEntity.PART_SPOILER, new Item.Properties()));

    public CarMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        bus.addListener(this::tab);
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(Net::init));
    }

    private void tab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            e.accept(SPORTS_CAR);
            e.accept(CITY_VAN);
            e.accept(AIR_FRESHENER);
            e.accept(FLOOR_MAT);
            e.accept(SPOILER);
        }
    }

    @Mod.EventBusSubscriber(modid = ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientEvents {
        @SubscribeEvent
        public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
            e.registerEntityRenderer(CAR.get(), CarRenderer::new);
        }
    }
}
