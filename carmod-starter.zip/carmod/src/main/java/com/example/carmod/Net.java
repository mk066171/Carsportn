package com.example.carmod;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class Net {
    private static final String V = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(CarMod.ID, "main"), () -> V, V::equals, V::equals);

    public static void init() {
        CH.registerMessage(0, FlashPacket.class, FlashPacket::encode, FlashPacket::decode, FlashPacket::handle);
    }
}
